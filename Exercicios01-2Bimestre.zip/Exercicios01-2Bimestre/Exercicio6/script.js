let inputNumber1 = document.querySelector("#inputNumber1");
let inputNumber2 = document.querySelector("#inputNumber2");
let inputNumber3 = document.querySelector("#inputNumber3");
let inputNumber4 = document.querySelector("#inputNumber4");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculo(){
    let num1 = Number(inputNumber1.value);
    let num2 = Number(inputNumber2.value);
    let num3 = Number(inputNumber3.value);
    let num4 = Number(inputNumber4.value);

    if ((num1 < num2) && (num1 < num3) && (num1 < num4)) {
        resultado.innerHTML = " O menor numero é " + num1;
    }
    else if ((num2 < num1) && (num2 < num3) && (num2 < num4)){
        resultado.innerHTML = " O menor numero é " + num2;
    }
    else if((num3 < num1) && (num3 < num2) && (num3 < num4)){
        resultado.innerHTML = " O menor numero é " + num3;
    }
    else {
        resultado.textContent = " O menor numero é " + num4;
    }

}

btCalcular.onclick = function (){
    calculo();
}

