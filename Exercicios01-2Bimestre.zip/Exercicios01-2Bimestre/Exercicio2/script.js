let inputQuiloValor = document.querySelector("#inputQuiloValor");
let inputQuiloProduto = document.querySelector("#inputQuiloProduto");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularPreçoFinal(){
    let num1 = Number(inputQuiloValor.value);
    let num2 = Number(inputQuiloProduto.value);

    resultado.textContent = (num1 * num2);
}

btCalcular.onclick = function (){
    calcularPreçoFinal();
}