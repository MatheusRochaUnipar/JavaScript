let inputNumber1 = document.querySelector("#inputNumber1");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculo() {
    let num1 = Number(inputNumber1.value);

    if (num1 % 2 == 0){
        resultado.innerHTML = "O número é par";
    } 
    else if (num1 % 2 == 1){
        resultado.innerHTML = "O número é ímpar";
    }
    else {
        resultado.innerHTML = "Número invalido";
    }
}

btCalcular.onclick = function () {
    calculo();
}

