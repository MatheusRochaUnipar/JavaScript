let inputSaldo = document.querySelector("#inputSaldo");
let btCalcular = document.querySelector("#btCalcular");
let resultado= document.querySelector("#resultado");

function calcularReajuste(){
    let num1 = Number(inputSaldo.value)

    resultado.textContent = (num1 * 1) / 100 + num1;
}

btCalcular.onclick = function (){
    calcularReajuste();
}