let valorProduto = document.querySelector("#valorProduto");
let valorPago = document.querySelector("#valorPago");
let btCalculo = document.querySelector("#btCalculo");
let resultado = document.querySelector("#resultado");

function calcularTroco(){
    let num1 = Number(valorProduto.value);
    let num2 = Number(valorPago.value);

    resultado.textContent = (num2 - num1);
}

btCalculo.onclick = function (){
    calcularTroco();
}