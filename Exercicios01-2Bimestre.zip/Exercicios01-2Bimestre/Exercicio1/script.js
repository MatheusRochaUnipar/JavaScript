let valorProduto = document.querySelector("#inputNumber1");
let valorPago = document.querySelector("#inputNumber2");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularTroco(){
    let num1 = Number(valorProduto.value);
    let num2 = Number(valorPago.value);

    resultado.textContent = (num2 - num1);
}

btCalcular.onclick = function (){
    calcularTroco();
}