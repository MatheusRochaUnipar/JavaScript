let inputNumber1 = document.querySelector("#inputNumber1");
let inputNumber2 = document.querySelector("#inputNumber2");
let inputNumber3 = document.querySelector("#inputNumber3");
let btCalcular = document.querySelector("#btCalcular");

let resultadoA = document.querySelector("#resultadoA");
let resultadoB = document.querySelector("#resultadoB");
let resultadoC = document.querySelector("#resultadoC");
let resultadoD = document.querySelector("#resultadoD");

function mediaAritmetica(){
    let num1 = Number(inputNumber1.value)
    let num2 = Number(inputNumber2.value)
    let num3 = Number(inputNumber3.value)
    let resultA = (num1 + num2 + num3) / 3;

    resultadoA.textContent = resultA;

    return resultA;
}

function mediaPonderada(){
    let num1 = Number(inputNumber1.value)
    let num2 = Number(inputNumber2.value)
    let num3 = Number(inputNumber3.value)
    let resultB = (num1 * 3) + (num2 * 2) + (num3 * 5) / 3;

    resultadoB.textContent = resultB; 

    return resultB;
}

function somaMedia(){
    
    let resultC = (mediaAritmetica()) + (mediaPonderada());

    resultadoC.textContent = resultC;

    return resultC;
}

function mediaDasMedia(){

    let resultD = (somaMedia() / 2);

    resultadoD.textContent = resultD;

}

btCalcular.onclick = function (){
    mediaAritmetica();
    mediaPonderada();
    somaMedia();
    mediaDasMedia();
}