let inputNum1 = document.querySelector("#inputNum1") 
let inputNum2 = document.querySelector("#inputNum2")
let btSomar = document.querySelector("#btSomar")
let resultado = document.querySelector("#resultado")

function somarValores(){
    //retornando os numeros digitados e jogando em outra variavel
    //transformando eles em numeros com a propriedade Number
    let num1 = Number(inputNum1.value);
    let num2 = Number(inputNum2.value);
    //Atribuindo ao elemento resultado a soma dos dois numeros digitados
    resultado.textContent = (num1 + num2);    
}
//Atribuindo uma ação de clicar no botão
btSomar.onclick = function(){
    somarValores();
}