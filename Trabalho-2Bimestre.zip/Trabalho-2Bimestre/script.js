// Exercício 1

let inputX = document.querySelector("#inputX");
let inputY = document.querySelector("#inputY");
let inputZ = document.querySelector("#inputZ");
let btVerificaTriangulo = document.querySelector("#btVerificaTriangulo");
let resultadoTriangulo = document.querySelector("#resultadoTriangulo");

function verificaTriangulo(){
    let x = Number(inputX.value);
    let y = Number(inputY.value);
    let z = Number(inputZ.value);

    if ((x + y > z) && (x + z > y) && (y + z > x)){
        if((x == y) && (y == z)){
            resultadoTriangulo.innerHTML = "Seu triângulos é Equilátero.";
        }
        else if((x == y) || (x == z) || (y == z)){
            resultadoTriangulo.innerHTML = "Seu triângulos é Isósceles.";
        }
        else{
            resultadoTriangulo.innerHTML = "Seu triângulos é Escaleno.";
        }
    }
    else {
        resultadoTriangulo.innerHTML = "Os lados fornecidos não formam um triângulo válido.";
    }
}

btVerificaTriangulo.onclick = function (){
    verificaTriangulo();
}

// Exercício 2 

let inputPeso = document.querySelector("#inputPeso");
let inputAltura = document.querySelector("#inputAltura");
let btCalcularIMC = document.querySelector("#btCalcularIMC");
let resultadoIMC = document.querySelector("#resultadoIMC");

function calcularIMC(){
    let peso = parseFloat(inputPeso.value);
    let altura = parseFloat(inputAltura.value);
    let alturaAoQuadrado = (altura ** 2);
    let valorIMC = (peso / alturaAoQuadrado).toFixed(1);

    if((peso > 0) && (altura > 0)){
        if(valorIMC < 18.5){
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Abaixo do peso.";
        }
        else if((valorIMC >= 18.5) && (valorIMC <= 24.9)){
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Peso normal.";
        }
        else if((valorIMC >= 25) && (valorIMC <= 29.9)){
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Sobrepeso.";
        }
        else if((valorIMC >= 30) && (valorIMC <= 34.9)){
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Obesidade grau 1.";
        }
        else if((valorIMC >= 35) && (valorIMC <= 39.9)){
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Obesidade grau 2.";
        }
        else{
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Obesidade grau 3.";
        }
    }
    else {
        resultadoIMC.innerHTML = "Dados inválidos.";
    }
}

btCalcularIMC.onclick = function (){
    calcularIMC();
}


// Exercício 3

let inputAno = document.querySelector("#inputAno");
let inputTabela = document.querySelector("#inputTabela");
let btCalcularImposto = document.querySelector("#btCalcularImposto");
let resultadoImpostoCarro = document.querySelector("#resultadoImpostoCarro");

function calcularImpostoCarro(){
    let ano = Number(inputAno.value);
    let tabela = parseFloat(inputTabela.value);
    let taxa1 = (tabela * 1 / 100);
    let taxa2 = (tabela * 1.5 / 100);
    
    if(ano > 0){
        if(ano < 1990){
            resultadoImpostoCarro.innerHTML = "Imposto a ser pago: R$ " + taxa1.toFixed(2);
        }
        else if(ano >= 1990){
            resultadoImpostoCarro.innerHTML = "Imposto a ser pago: R$ " + taxa2.toFixed(2);
        }
    }
    else{
        resultadoImpostoCarro.innerHTML = "Dados inválidos.";
    }
}

btCalcularImposto.onclick = function (){
    calcularImpostoCarro();
}

// Exercício 4

let inputSalario = document.querySelector("#inputSalario");
let inputCargo = document.querySelector("#inputCargo");
let btCalcularSalario = document.querySelector("#btCalcularSalario");
let resultadoSalario = document.querySelector("#resultadoSalario");

function calcularSalario() {
    let salarioInicial = parseFloat(inputSalario.value);
    let cargo = inputCargo.value;

    let reajusteGerente = salarioInicial * 10 / 100;
    let salarioGerenteFinal = salarioInicial + reajusteGerente;

    let reajusteEngenheiro = salarioInicial * 20 / 100;
    let salarioEngenheiroFinal = salarioInicial + reajusteEngenheiro;

    let reajusteTecnico = salarioInicial * 30 / 100;
    let salarioTecnicoFinal = salarioInicial + reajusteTecnico;

    let reajusteCargoNaoListado = salarioInicial * 40 / 100;
    let salarioCargoNaoListadoFinal = salarioInicial + reajusteCargoNaoListado;

    if (cargo === "101") {
        resultadoSalario.innerHTML =
            "Salário antigo: R$ " + salarioInicial.toFixed(2) + "<br><hr>" +
            "Salário novo: R$ " + salarioGerenteFinal.toFixed(2) + "<br><hr>" +
            "Diferença: R$ " + reajusteGerente.toFixed(2) + "<hr>";
    }
    else if (cargo === "102") {
        resultadoSalario.innerHTML =
            "Salário antigo: R$ " + salarioInicial.toFixed(2) + "<br><hr>" +
            "Salário novo: R$ " + salarioEngenheiroFinal.toFixed(2) + "<br><hr>" +
            "Diferença: R$ " + reajusteEngenheiro.toFixed(2) + "<hr>";
    }
    else if (cargo === "103") {
        resultadoSalario.innerHTML =
            "Salário antigo: R$ " + salarioInicial.toFixed(2) + "<br><hr>" +
            "Salário novo: R$ " + salarioTecnicoFinal.toFixed(2) + "<br><hr>" +
            "Diferença: R$ " + reajusteTecnico.toFixed(2) + "<hr>";
    }
    else if (cargo === "104") {
        resultadoSalario.innerHTML =
            "Salário antigo: R$ " + salarioInicial.toFixed(2) + "<br><hr>" +
            "Salário novo: R$ " + salarioCargoNaoListadoFinal.toFixed(2) + "<br><hr>" +
            "Diferença: R$ " + reajusteCargoNaoListado.toFixed(2) + "<hr>";
    }
    else {
        resultadoSalario.innerHTML = "Dados inválidos.";
    }
}

btCalcularSalario.onclick = function () {
    calcularSalario();
}
