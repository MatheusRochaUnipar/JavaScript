// Exercício 1

let inputX = document.querySelector("#inputX");
let inputY = document.querySelector("#inputY");
let inputZ = document.querySelector("#inputZ");
let btVerificaTriangulo = document.querySelector("#btVerificaTriangulo");
let resultadoTriangulo = document.querySelector("#resultadoTriangulo");

function verificaTriangulo(){
    let x = Number(inputX.value);
    let y = Number(inputY.value);
    let z = Number(inputZ.value);

    if ((x + y > z) && (x + z > y) && (y + z > x)){
        if((x == y) && (y == z)){
            resultadoTriangulo.innerHTML = "Seu triângulo é Equilátero.";
        }
        else if((x == y) || (x == z) || (y == z)){
            resultadoTriangulo.innerHTML = "Seu triângulo é Isósceles.";
        }
        else{
            resultadoTriangulo.innerHTML = "Seu triângulo é Escaleno.";
        }
    }
    else {
        resultadoTriangulo.innerHTML = "Os lados fornecidos não formam um triângulo válido.";
    }
}

btVerificaTriangulo.onclick = function (){
    verificaTriangulo();
}

// Exercício 2 

let inputPeso = document.querySelector("#inputPeso");
let inputAltura = document.querySelector("#inputAltura");
let btCalcularIMC = document.querySelector("#btCalcularIMC");
let resultadoIMC = document.querySelector("#resultadoIMC");

function calcularIMC(){
    let peso = parseFloat(inputPeso.value);
    let altura = parseFloat(inputAltura.value);
    let alturaAoQuadrado = (altura ** 2);
    let valorIMC = (peso / alturaAoQuadrado).toFixed(1);

    if((peso > 0) && (altura > 0)){
        if(valorIMC < 18.5){
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Abaixo do peso.";
        }
        else if((valorIMC >= 18.5) && (valorIMC <= 24.9)){
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Peso normal.";
        }
        else if((valorIMC >= 25) && (valorIMC <= 29.9)){
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Sobrepeso.";
        }
        else if((valorIMC >= 30) && (valorIMC <= 34.9)){
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Obesidade grau 1.";
        }
        else if((valorIMC >= 35) && (valorIMC <= 39.9)){
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Obesidade grau 2.";
        }
        else{
            resultadoIMC.innerHTML = "Seu IMC é de: " + valorIMC + " e sua classificação é: Obesidade grau 3.";
        }
    }
    else {
        resultadoIMC.innerHTML = "Dados inválidos.";
    }
}

btCalcularIMC.onclick = function (){
    calcularIMC();
}

// Exercício 3

let inputAno = document.querySelector("#inputAno");
let inputTabela = document.querySelector("#inputTabela");
let btCalcularImposto = document.querySelector("#btCalcularImposto");
let resultadoImpostoCarro = document.querySelector("#resultadoImpostoCarro");

function calcularImpostoCarro(){
    let ano = Number(inputAno.value);
    let tabela = parseFloat(inputTabela.value);
    let taxa1 = (tabela * 1 / 100);
    let taxa2 = (tabela * 1.5 / 100);
    
    if(ano > 0){
        if(ano < 1990){
            resultadoImpostoCarro.innerHTML = "Imposto a ser pago: R$ " + taxa1.toFixed(2);
        }
        else if(ano >= 1990){
            resultadoImpostoCarro.innerHTML = "Imposto a ser pago: R$ " + taxa2.toFixed(2);
        }
    }
    else{
        resultadoImpostoCarro.innerHTML = "Dados inválidos.";
    }
}

btCalcularImposto.onclick = function (){
    calcularImpostoCarro();
}

// Exercício 4

let inputSalario = document.querySelector("#inputSalario");
let inputCargo = document.querySelector("#inputCargo");
let btCalcularSalario = document.querySelector("#btCalcularSalario");
let resultadoSalario = document.querySelector("#resultadoSalario");

function calcularSalario() {
    let salarioInicial = parseFloat(inputSalario.value);
    let cargo = (inputCargo.value);

    let reajusteGerente = salarioInicial * 10 / 100;
    let salarioGerenteFinal = salarioInicial + reajusteGerente;

    let reajusteEngenheiro = salarioInicial * 20 / 100;
    let salarioEngenheiroFinal = salarioInicial + reajusteEngenheiro;

    let reajusteTecnico = salarioInicial * 30 / 100;
    let salarioTecnicoFinal = salarioInicial + reajusteTecnico;

    let reajusteCargoNaoListado = salarioInicial * 40 / 100;
    let salarioCargoNaoListadoFinal = salarioInicial + reajusteCargoNaoListado;

    if (cargo === "101") {
        resultadoSalario.innerHTML =
            "Salário antigo: R$ " + salarioInicial.toFixed(2) + "<br><hr>" +
            "Salário novo: R$ " + salarioGerenteFinal.toFixed(2) + "<br><hr>" +
            "Diferença: R$ " + reajusteGerente.toFixed(2) + "<hr>";
    }
    else if (cargo === "102") {
        resultadoSalario.innerHTML =
            "Salário antigo: R$ " + salarioInicial.toFixed(2) + "<br><hr>" +
            "Salário novo: R$ " + salarioEngenheiroFinal.toFixed(2) + "<br><hr>" +
            "Diferença: R$ " + reajusteEngenheiro.toFixed(2) + "<hr>";
    }
    else if (cargo === "103") {
        resultadoSalario.innerHTML =
            "Salário antigo: R$ " + salarioInicial.toFixed(2) + "<br><hr>" +
            "Salário novo: R$ " + salarioTecnicoFinal.toFixed(2) + "<br><hr>" +
            "Diferença: R$ " + reajusteTecnico.toFixed(2) + "<hr>";
    }
    else if (cargo === "104") {
        resultadoSalario.innerHTML =
            "Salário antigo: R$ " + salarioInicial.toFixed(2) + "<br><hr>" +
            "Salário novo: R$ " + salarioCargoNaoListadoFinal.toFixed(2) + "<br><hr>" +
            "Diferença: R$ " + reajusteCargoNaoListado.toFixed(2) + "<hr>";
    }
    else {
        resultadoSalario.innerHTML = "Dados inválidos.";
    }
}

// Exercício 5


btCalcularSalario.onclick = function () {
    calcularSalario();
}

let SaldoMedio = document.querySelector("#SaldoMedio");
let CreditoResultado = document.querySelector("#CreditoResultado");
let BtnCalcularCredito = document.querySelector("#BtnCalcularCredito");

BtnCalcularCredito.addEventListener("click", function () {
    let saldo = Number(SaldoMedio.value);
    let credito = 0;
    let mensagem = "";

    if (saldo < 0 || isNaN(saldo)) {
        mensagem = "Digite um saldo médio válido.";
    } else {
        if (saldo <= 200) {
            credito = 0;
            mensagem = "Nenhum crédito disponível.";
        } else if (saldo <= 400) {
            credito = saldo * 0.20;
            mensagem = "Você tem direito a 20% de crédito.";
        } else if (saldo <= 600) {
            credito = saldo * 0.30;
            mensagem = "Você tem direito a 30% de crédito.";
        } else {
            credito = saldo * 0.40;
            mensagem = "Você tem direito a 40% de crédito.";
        }

        mensagem += " Saldo médio: R$ " + saldo.toFixed(2);
        if (credito > 0) {
            mensagem += " | Crédito concedido: R$ " + credito.toFixed(2);
        }
    }

    CreditoResultado.textContent = mensagem;
});

// Exercício 6

let CodigoItem = document.querySelector("#CodigoItem");
let QuantidadeItem = document.querySelector("#QuantidadeItem");
let TotalPedido = document.querySelector("#TotalPedido");
let CalcularPedido = document.querySelector("#CalcularPedido");

CalcularPedido.addEventListener("click", function () {
    let codigo = CodigoItem.value;
    let quantidade = Number(QuantidadeItem.value);
    let preco = 0;
    let nome = "";

    if (codigo === "1") {
        preco = 11;
        nome = "Cachorro Quente";
    } else if (codigo === "2") {
        preco = 8.5;
        nome = "Bauru";
    } else if (codigo === "3") {
        preco = 8;
        nome = "Misto Quente";
    } else if (codigo === "4") {
        preco = 9;
        nome = "Hamburguer";
    } else if (codigo === "5") {
        preco = 10;
        nome = "Cheeseburger";
    } else if (codigo === "6") {
        preco = 4.5;
        nome = "Refrigerante";
    } else {
        TotalPedido.textContent = "Código inválido.";
        return;
    }

    let total = preco * quantidade;

    TotalPedido.textContent = "Item: " + nome + " | Total a pagar: R$ " + total.toFixed(2);
});

// Exercício 7

let PrecoEtiqueta = document.querySelector("#PrecoEtiqueta");
let CodigoPagamento = document.querySelector("#CodigoPagamento");
let VendaResultado = document.querySelector("#VendaResultado");
let BtnCalcularVenda = document.querySelector("#BtnCalcularVenda");

BtnCalcularVenda.addEventListener("click", function () {
    let preco = Number(PrecoEtiqueta.value);
    let codigo = CodigoPagamento.value.toLowerCase(); 
    let valorFinal = 0;

    if (preco <= 0 || isNaN(preco) || !["a", "b", "c", "d"].includes(codigo)) {
        VendaResultado.textContent = "Preencha o preço e código corretamente (a, b, c ou d).";
    } else {
        if (codigo === "a") {
            valorFinal = preco * 0.9; 
        } else if (codigo === "b") {
            valorFinal = preco * 0.85; 
        } else if (codigo === "c") {
            valorFinal = preco; 
        } else if (codigo === "d") {
            valorFinal = preco * 1.10; 
        }

        VendaResultado.textContent = "Valor a pagar: R$ " + valorFinal.toFixed(2);
    }
});

// Exercício 8


let NivelProfessor = document.querySelector("#NivelProfessor");
let HorasSemana = document.querySelector("#HorasSemana");
let SalarioResultado = document.querySelector("#SalarioResultado");
let BtnCalcularSalario = document.querySelector("#BtnCalcularSalario");

BtnCalcularSalario.addEventListener("click", function () {
    let nivel = Number(NivelProfessor.value);
    let horas = Number(HorasSemana.value);
    let valorHora = 0;
    let salario = 0;

    if ((nivel !== 1 && nivel !== 2 && nivel !== 3) || horas <= 0 || isNaN(horas)) {
        SalarioResultado.textContent = "Preencha corretamente o nível (1, 2 ou 3) e as horas.";
    } else {
        if (nivel === 1) {
            valorHora = 12;
        } else if (nivel === 2) {
            valorHora = 17;
        } else if (nivel === 3) {
            valorHora = 25;
        }

        salario = valorHora * horas * 4.5;

        SalarioResultado.textContent = "Salário do professor: R$ " + salario.toFixed(2);
    }
});

// Interação de escolha

const tituloMenu = document.getElementById('tituloMenu');
const menu = document.getElementById('menu');
const botaoVoltar = document.getElementById('botaoVoltar');
const cards = document.querySelectorAll('.card');

function mostrarCard(id) {

    cards.forEach(card => card.style.display = 'none');

    const cardSelecionado = document.getElementById(id);
    if (cardSelecionado) {
        cardSelecionado.style.display = 'block';
    }

    tituloMenu.style.display = 'none';
    menu.style.display = 'none';

    botaoVoltar.style.display = 'inline-block';
}

botaoVoltar.addEventListener('click', () => {

    cards.forEach(card => card.style.display = 'none');

    tituloMenu.style.display = 'block';
    menu.style.display = 'grid';
    
    botaoVoltar.style.display = 'none';
});
