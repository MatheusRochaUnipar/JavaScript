let inputNumber1 = document.querySelector("#inputNumber1")
let inputNumber2 = document.querySelector("#inputNumber2")
let btCalcular = document.querySelector("#btCalcular")
let resultado = document.querySelector("#resultado")

function calculo(){
    let num1 = Number(inputNumber1.value)
    let num2 = Number(inputNumber2.value)
    let area = (num1 * num2);

    resultado.innerHTML = "<h3>Área do seu terreno retangular é </h3>" + area + " m²";
}

btCalcular.onclick = function (){
    calculo();
}
