let inputNumber1 = document.querySelector("#inputNumber1")
let btCalcular = document.querySelector("#btCalcular")
let resultado = document.querySelector("#resultado")

function calculo(){
    let num1 = Number(inputNumber1.value)

    resultado.innerHTML = num1;
}

btCalcular.onclick = function (){
    calculo();
}
