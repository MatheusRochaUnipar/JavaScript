let inputNumber1 = document.querySelector("#inputNumber1");
let inputNumber2 = document.querySelector("#inputNumber2");
let inputNumber3 = document.querySelector("#inputNumber3");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoValorCamisas(){
    let num1 = Number(inputNumber1.value);
    let num2 = Number(inputNumber2.value);
    let num3 = Number(inputNumber3.value);
    let camisas = ((num1 * 10) + (num2 * 12) + (num3 * 15));
    
    resultado.innerHTML = ("Valor total arrecadado: " + camisas + " Reais" + "<hr>");

    return camisas;

}

btCalcular.onclick = function (){
    calculoValorCamisas();
}