let inputNumber1 = document.querySelector("#inputNumber1");
let inputNumber2 = document.querySelector("#inputNumber2");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoDiasVividos(){
    let num1 = inputNumber1.value;
    let num2 = Number(inputNumber2.value);
    let result = (num2 * 365);

    resultado.innerHTML = num1 + ",Você já viveu " + result + " dias.";
}

btCalcular.onclick = function (){
    calculoDiasVividos();
}
