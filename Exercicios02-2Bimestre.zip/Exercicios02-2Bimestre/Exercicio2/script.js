let inputNumber1 = document.querySelector("#inputNumber1")
let btCalcular = document.querySelector("#btCalcular")
let resultadoA = document.querySelector("#resultadoA")
let resultadoB = document.querySelector("#resultadoB")

function calculo(){
    let num1 = Number(inputNumber1.value);

    resultadoA.textContent = num1 * 2;
    resultadoB.textContent = num1 * 50 + ",00 g" ;
}

btCalcular.onclick = function (){
    calculo();
}