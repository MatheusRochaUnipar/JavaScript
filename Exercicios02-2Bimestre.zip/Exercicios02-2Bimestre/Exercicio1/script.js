let inputNumber1 = document.querySelector("#inputNumber1");
let btCalcular = document.querySelector("#btCalcular");
let resultadoA = document.querySelector("#resultadoA");
let resultadoB = document.querySelector("#resultadoB");
let resultadoC = document.querySelector("#resultadoC");
let resultadoD = document.querySelector("#resultadoD");

function reajuste(){
    let num1 = Number(inputNumber1.value)

    resultadoA.textContent = (num1 * 1) / 100 + num1;
    resultadoB.textContent = (num1 * 2) / 100 + num1;
    resultadoC.textContent = (num1 * 5) / 100 + num1;
    resultadoD.textContent = (num1 * 10) / 100 + num1;
}

btCalcular.onclick = function (){
    reajuste();
}