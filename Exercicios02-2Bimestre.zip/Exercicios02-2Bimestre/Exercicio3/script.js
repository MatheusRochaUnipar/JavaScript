let inputNumber1 = document.querySelector("#inputNumber1");
let inputNumber2 = document.querySelector("#inputNumber2");
let btCalcular = document.querySelector("#btCalcular");

let resultadoA = document.querySelector("#resultadoA");
let resultadoB = document.querySelector("#resultadoB");
let resultadoC = document.querySelector("#resultadoC");
let resultadoD = document.querySelector("#resultadoD");

function calculosMatematicos(){
    let num1 = Number(inputNumber1.value);
    let num2 = Number(inputNumber2.value);

    resultadoA.textContent = (num1 + num2);
    resultadoB.textContent = (num1 - num2);
    resultadoC.textContent = (num1 * num2);
    resultadoD.textContent = (num1 / num2);
}

btCalcular.onclick = function (){
    calculosMatematicos();
}