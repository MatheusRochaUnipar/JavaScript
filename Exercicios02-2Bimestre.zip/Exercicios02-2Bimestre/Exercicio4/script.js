let inputNumber1 = document.querySelector("#inputNumber1");
let inputNumber2 = document.querySelector("#inputNumber2");
let inputNumber3 = document.querySelector("#inputNumber3");
let inputNumber4 = document.querySelector("#inputNumber4");
let inputNumber5 = document.querySelector("#inputNumber5");

let btCalcular = document.querySelector("#btCalcular");
let resultadoA = document.querySelector("#resultadoA");
let resultadoB = document.querySelector("#resultadoB");


function calcularPreço(){
    let pizza1 = inputNumber1.value;
    let pizza2 = inputNumber2.value;
    let pizza3 = inputNumber3.value;
    let pizza4 = inputNumber4.value;
    let num5 = Number(inputNumber5.value);
    
    resultadoA.innerHTML = "1." + pizza1 + " " + "<br>" + "2." + pizza2 + " " + "<br>" + "3." + pizza3 + " " + "<br>" + "4." + pizza4;
    resultadoB.innerHTML = "<h3>4 Pizzas = 48 Reais </h3>" + "<h3>Refrigerantes = </h3>" +  (num5 * 7 + " Reais") +  "<h3> Valor total a pagar =</h3>" + ((num5 * 7) + 48) + " Reais";

}

btCalcular.onclick = function (){
    calcularPreço();
}